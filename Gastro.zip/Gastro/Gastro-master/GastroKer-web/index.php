<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<!DOCTYPE html>
	<html lang = "hu">
		<head>
			<meta charset = "utf8" name="viewport" content="width=device-width, initial-scale=1.0">
			<title></title>
			<link rel = "stylesheet" href ="https://www.w3schools.com/w3css/4/w3.css">
			<link rel = "stylesheet" href ="w3style.css">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		</head>	
		<body>
				<nav class = "w3-bar w3-red" id="bar">
					<div class = "w3-bar-item w3-button w3-mobile">Főoldal</div>
					<div class = "w3-bar-item w3-button w3-mobile">Belépés</div>
					<div class = "w3-bar-item w3-button w3-mobile">Regisztráció</div>
					<div class = "w3-bar-item w3-button w3-mobile">Kapcsolat</div>
				</nav>
		







			<p>szövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
                        szövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszö
                        szövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszö
                        szövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszö
                        szövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszö
                        
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
			szövegszövegszövegszöveg
		
		</body>
	</html>