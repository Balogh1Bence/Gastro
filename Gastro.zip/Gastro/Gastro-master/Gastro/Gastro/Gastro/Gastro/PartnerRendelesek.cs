﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConnectToMysqlDatabase;

namespace Gastro
{
    public partial class PartnerRendelesek : Form
    {
        DataTable rend;
        int az;
        public PartnerRendelesek(int az)
        {
            this.az = az;
            InitializeComponent();
            Adatbazis a = new Adatbazis();
            MySQLDatabaseInterface mdi = new MySQLDatabaseInterface();
            mdi = a.kapcsolodas();
            mdi.open();
            rend = mdi.getToDataTable("select * from ");

        }
    }
}
