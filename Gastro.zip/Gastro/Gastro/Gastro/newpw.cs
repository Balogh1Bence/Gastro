﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gastro
{
    class newpw
    { 
        private string m;
       /* public string ujpw(currentuser cu)
            {
            
            string connectionString =
                  "SERVER=\"localhost\";"
                + "DATABASE=\"felh\";"
                + "UID=\"root\";"
                + "PASSWORD=\"\";"
                + "PORT=\"3306\";";
            MySqlConnection connection = new MySqlConnection(connectionString);

            try
            {
                connection.Open();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
                throw new Exception("nem jött össze");
            }

            try
            {








                MySqlCommand email = new MySqlCommand();
                email.Connection = connection;
                email.CommandText = "";
                email.Prepare();
                email.Parameters.AddWithValue("@azonosito", ());
                email.ExecuteReader();


            }
            catch (Exception e)
            {
                Debug.WriteLine("nem sikerült.");
            }
            return "";}*/

    }
}
